require 'test_helper'

class BookrersControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get bookrers_index_url
    assert_response :success
  end

  test "should get show" do
    get bookrers_show_url
    assert_response :success
  end

  test "should get new" do
    get bookrers_new_url
    assert_response :success
  end

  test "should get edit" do
    get bookrers_edit_url
    assert_response :success
  end

end
