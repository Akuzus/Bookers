class BooksController < ApplicationController

  def index
    @books = Book.all
    #Books一覧の表示用

    @book = Book.new
    #New Book用
  end


  def show
    @book = Book.find(params[:id])
  end

  def create
    @book = Book.new(book_params)
    if @book.save
      flash[:notice] = 'It was successfully posted.'
       redirect_to book_path(@book)
    else
      @books = Book.all
      render :index
    end
  end


  def edit
    @book = Book.find(params[:id])
  end


  def update
    @book = Book.find(params[:id])
    if @book.update(book_params)
       flash[:notice] = 'It was successfully posted.'
       redirect_to book_path(@book)
    else
      render :edit
    end
  end


  def destroy
    book = Book.find(params[:id])
    book.destroy
    flash[:notice] = 'Your post was successfully destroyed.'
    redirect_to books_path
  end


  private
  def book_params
    params.require(:book).permit(:title,:body)

  end

end
